# 極速搶票大師 (Ticket Master Pro)

這是一個由 AI 驅動的搶票訓練與監控工具。

## 部署教學
1. 將此資料夾所有檔案上傳至 GitHub。
2. 在 Vercel 匯入專案。
3. **重要**：在 Vercel Settings > Environment Variables 新增 `API_KEY`，填入你的 Gemini API Key。
